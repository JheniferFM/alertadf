module.exports = (req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.json({ key: process.env.GOOGLE_MAPS_API_KEY || '' });
};
