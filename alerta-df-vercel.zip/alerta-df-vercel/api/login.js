const crypto = require('crypto');
const { sign } = require('./_auth');
module.exports = (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();
  const esperado = process.env.ORGAO_CODE, c = String((req.body && req.body.codigo) || '');
  if (!esperado || !process.env.SESSION_SECRET) return res.status(500).json({ erro: 'nao_configurado' });
  const ok = c.length === esperado.length && crypto.timingSafeEqual(Buffer.from(c), Buffer.from(esperado));
  if (!ok) return res.status(401).json({ erro: 'invalido' });
  res.setHeader('Cache-Control', 'no-store');
  res.json({ token: sign() });
};
