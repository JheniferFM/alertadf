const crypto = require('crypto');
const seg = () => process.env.SESSION_SECRET;
const hmac = (p) => crypto.createHmac('sha256', seg()).update(p).digest('hex');
exports.sign = () => { const p = String(Date.now() + 8 * 3600e3); return p + '.' + hmac(p); };
exports.verify = (t) => {
  if (!t || !seg()) return false;
  const [p, s] = t.split('.');
  if (!p || !s) return false;
  const e = hmac(p);
  if (s.length !== e.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(e))) return false;
  return Number(p) > Date.now();
};
