// DADOS RESTRITOS (simulados) — substitua por consultas aos sistemas reais de cada órgão.
module.exports = {
  LIM: { h1: 20, h3: 45, h24: 80 }, // limiares críticos de chuva (mm) — ajuste com a Defesa Civil/INMET
  ANT: 48, // chuva antecedente de 5 dias (mm)
  EQ: [["CBMDF — viaturas de resgate",30],["NOVACAP — equipes de drenagem",15],["Defesa Civil — equipes de campo",10],["DER-DF — equipes de sinalização",8]],
  AB: [["Ginásio do Gama",400],["Escola em Sol Nascente",250],["Centro de Ensino em Ceilândia",300],["Ginásio de Planaltina",350]],
  HID: [["Lago Paranoá (% da capacidade)",78,.45],["Reservatório do Descoberto (%)",71,.25],["Córrego Vicente Pires (% da cota)",52,.9],["Córrego de Samambaia (% da cota)",48,.85]],
  PC: [["EPTG, Taguatinga",1,"flood","NOVACAP / DER-DF"],["Córrego em Vicente Pires",12,"flood","NOVACAP"],["Encosta em Sol Nascente",14,"slide","Defesa Civil"],["Encosta em São Sebastião",9,"slide","Defesa Civil"],["Galeria no Plano Piloto",0,"flood","NOVACAP / CAESB"]],
  POP: [230,210,350,230,135,130,190,100,70,115,55,130,40,70,90,10],
  INFRA: [[0,"Hospital de Base do DF","Hospital"],[1,"Hospital Regional de Taguatinga","Hospital"],[2,"Hospital Regional de Ceilândia","Hospital"],[3,"Hospital Regional de Samambaia","Hospital"],[4,"Hospital Regional do Gama","Hospital"],[5,"Hospital Regional de Santa Maria","Hospital"],[6,"Hospital Regional de Planaltina","Hospital"],[7,"Hospital Regional de Sobradinho","Hospital"],[8,"Hospital Regional do Paranoá","Hospital"],[10,"Hospital Regional de Brazlândia","Hospital"],[14,"Escolas e UBS de Sol Nascente","Escolas/UBS"],[9,"Escolas rurais de São Sebastião","Escolas"]],
  OC: [
    ["OC-0412","Alagamento","EPTG, sentido Plano Piloto","há 12 min","Alta","CBMDF / DER-DF","Equipe a caminho"],
    ["OC-0411","Deslizamento","Sol Nascente, Trecho 2","há 35 min","Alta","Defesa Civil","No local"],
    ["OC-0409","Queda de árvore","Asa Norte, W3","há 1 h","Média","NOVACAP","Em atendimento"],
    ["OC-0407","Alagamento","Setor Comercial Sul, Taguatinga","há 2 h","Média","NOVACAP","Aguardando equipe"],
    ["OC-0405","Descarga elétrica","Sobradinho II","há 3 h","Baixa","Neoenergia","Concluída"]
  ],
  PROTO: [
    [["INMET / CEMADEN","Manter monitoramento e emitir boletins de rotina."],["Defesa Civil","Verificar a prontidão de equipes e abrigos."]],
    [["NOVACAP","Limpar bocas de lobo e galerias nos pontos críticos."],["Defesa Civil","Notificar regiões em atenção e pré-posicionar equipes."],["CBMDF","Reforçar o plantão do 193."]],
    [["NOVACAP","Enviar equipes de drenagem aos pontos críticos em nível alto."],["CBMDF","Pré-posicionar viaturas e resgate em regiões altas."],["DER-DF","Sinalizar e preparar a interdição de vias alagáveis."],["Defesa Civil","Alertar por SMS as áreas de encosta e alagamento; abrir abrigos de apoio."],["CAESB / Neoenergia","Manter equipes de prontidão para falhas de água, esgoto e energia."]],
    [["Defesa Civil","Ativar o centro de operações; decidir remoção preventiva em áreas de deslizamento; abrir abrigos."],["CBMDF","Empenhar todas as viaturas de resgate; priorizar vítimas e áreas isoladas."],["NOVACAP","Operar a drenagem em regime contínuo; priorizar vias de acesso a hospitais."],["DER-DF / Detran","Interditar vias alagadas e divulgar rotas alternativas."],["SES-DF","Acionar o plano de contingência dos hospitais regionais."],["Neoenergia / CAESB","Priorizar o restabelecimento de serviços a hospitais e abrigos."]]
  ]
};
