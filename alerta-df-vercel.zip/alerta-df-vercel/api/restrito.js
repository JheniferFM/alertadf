const { verify } = require('./_auth');
const dados = require('./_dados');
module.exports = (req, res) => {
  const t = (req.headers.authorization || '').replace(/^Bearer /, '');
  if (!verify(t)) return res.status(401).json({ erro: 'nao_autorizado' });
  res.setHeader('Cache-Control', 'no-store');
  res.json(dados);
};
