# ALERTA DF — deploy na Vercel
1. Suba esta pasta em um repositório (GitHub) e importe na Vercel (framework: Other).
2. Em Settings > Environment Variables, crie:
   - GOOGLE_MAPS_API_KEY : chave da Maps JavaScript API
   - ORGAO_CODE          : código de acesso do perfil órgão
   - SESSION_SECRET      : texto aleatório longo (32+ caracteres)
3. No Google Cloud, restrinja a chave por HTTP referrer ao seu domínio (https://SEU-PROJETO.vercel.app/*).
4. Faça o deploy. Os dados restritos só saem de /api/restrito com token válido.
